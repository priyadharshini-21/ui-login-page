# Responsive Personal Portfolio Hero

A responsive personal portfolio hero-section starter built with HTML and CSS.

## Run locally
1. Extract the ZIP file.
2. Open `index.html` in a browser.

No npm install or build step is required.

## Customize before submitting
- Replace `Alex Morgan` with your name.
- Update the intro text, navigation links, and social/contact links.
- Replace the CSS portrait illustration with your own image if the task's Figma design requires a real portrait.
- Match spacing, colors, fonts, and imagery to the exact Figma reference if one was provided.

This is a front-end starter, not a pixel-perfect conversion of a Figma file because no Figma screenshot/link was included.
