# Responsive Login Page

A responsive login-page UI based on the reference shown in the task screenshot.

## Run
1. Extract this ZIP.
2. Open `index.html` in Chrome, Edge, or Firefox.

No build tools or package installation are required.

## Note
This is the front-end UI only. The sign-in form is not connected to a real authentication service. The background photo loads from Unsplash and therefore requires an internet connection.
